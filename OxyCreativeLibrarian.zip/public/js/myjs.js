$(document).ready(function () {
    $(".chosen-select").chosen({ no_results_text: "Oops, nothing found!", width: "100%"});
});
