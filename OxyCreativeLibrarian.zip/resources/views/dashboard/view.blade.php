@extends('layouts.view')
@section('content')
    <div class="main" style="min-height:600px;display:flex;align-items:center;">
        <div class="intro" style="margin:0px auto;">
            <h1 class="text-center">Oxy Cretive Library Management</h1>
        </div>
    </div>
@endsection
