@include('inc.header')
@include('inc.sidebar')
@include('inc.topnav')

@yield('content')

@include('inc.footer')
