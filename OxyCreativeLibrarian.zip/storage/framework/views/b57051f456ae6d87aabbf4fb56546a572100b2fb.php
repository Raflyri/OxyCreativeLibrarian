<?php $__env->startSection('content'); ?>
    <div class="main" style="min-height:600px;display:flex;align-items:center;">
        <div class="intro" style="margin:0px auto;">
            <h1 class="text-center">Oxy Cretive Library Management</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Simple-Library-Management-System-for-Librarian-with-Laravel-\resources\views/dashboard/view.blade.php ENDPATH**/ ?>